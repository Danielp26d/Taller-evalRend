/*#######################################################################################
 #* Fecha: 
 #* Autor: J. Corredor, PhD
 #* Módulo: modmul (Multiplicación de matrices con concurrencia)
 #* Versión: 1.0
 #*
 #* Descripción:
 #* Este archivo de cabecera define las funciones necesarias para la manipulación
 #* y multiplicación de matrices utilizando técnicas de concurrencia y paralelismo.
 #* Incluye funciones para inicialización, impresión, transposición y multiplicación
 #* de matrices por segmentos (filas), permitiendo su ejecución en múltiples procesos
 #* o hilos.
 #*
 #* Funcionalidades principales:
 #*   - Inicialización de matrices
 #*   - Visualización de matrices
 #*   - Medición de tiempo de ejecución
 #*   - Transposición de matrices
 #*   - Multiplicación de matrices usando partición por filas
 #*
######################################################################################*/

#ifndef MODULOMM_H
#define MODULOMM_H

/**
 * @brief Inicializa dos matrices con valores (aleatorios o definidos).
 * 
 * @param m1 Puntero a la primera matriz.
 * @param m2 Puntero a la segunda matriz.
 * @param D Dimensión de las matrices (matrices cuadradas DxD).
 */
void iniMatrix(double *m1, double *m2, int D);

/**
 * @brief Marca el inicio de la medición de tiempo de ejecución.
 * 
 * Se utiliza para evaluar el rendimiento de los algoritmos de multiplicación.
 */
void InicioMuestra();

/**
 * @brief Marca el fin de la medición de tiempo de ejecución.
 * 
 * Generalmente se usa junto con InicioMuestra() para calcular el tiempo total.
 */
void FinMuestra();

/**
 * @brief Imprime una matriz en consola.
 * 
 * @param matrix Puntero a la matriz a imprimir.
 * @param D Dimensión de la matriz (DxD).
 */
void impMatrix(double *matrix, int D);

/**
 * @brief Calcula la transpuesta de una matriz.
 * 
 * @param N Dimensión de la matriz (NxN).
 * @param mB Puntero a la matriz original.
 * @param mT Puntero a la matriz transpuesta resultante.
 */
void matrixTRP(int N, double *mB, double *mT);

/**
 * @brief Multiplica matrices usando partición por filas (Fork por filas con matriz original).
 * 
 * Esta función calcula una porción del resultado (matriz C) multiplicando
 * las matrices A y B, procesando únicamente un rango de filas.
 * Ideal para paralelismo usando procesos/hilos.
 * 
 * @param mA Matriz A.
 * @param mB Matriz B.
 * @param mC Matriz resultado.
 * @param D Dimensión de las matrices (DxD).
 * @param filaI Fila inicial a procesar.
 * @param filaF Fila final a procesar.
 */
void mxmForkFxC(double *mA, double *mB, double *mC, int D, int filaI, int filaF);

/**
 * @brief Multiplica matrices usando partición por filas con matriz transpuesta.
 * 
 * Similar a mxmForkFxC, pero utiliza la matriz B transpuesta (mT) para mejorar
 * la localidad de memoria y el rendimiento.
 * 
 * @param mA Matriz A.
 * @param mT Matriz B transpuesta.
 * @param mC Matriz resultado.
 * @param D Dimensión de las matrices (DxD).
 * @param filaI Fila inicial a procesar.
 * @param filaF Fila final a procesar.
 */
void mxmForkFxT(double *mA, double *mT, double *mC, int D, int filaI, int filaF);

#endif
