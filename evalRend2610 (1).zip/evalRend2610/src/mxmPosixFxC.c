/*#######################################################################################
#* Fecha:
#* Autor: J. Corredor, PhD
#* Programa:
#*      Multiplicación de Matrices algoritmo clásico
#* Versión:
#*      Paralelismo con Hilos Pthreads "Posix" 
######################################################################################*/

#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include "moduloMM.h" 

/*------------------------------------------------------------------------------
 Variables globales
------------------------------------------------------------------------------*/

/* Mutex utilizado para sincronización entre hilos */
pthread_mutex_t MM_mutex;

/* Punteros globales para almacenar las matrices A, B y C */
double *matrixA, *matrixB, *matrixC;

/*------------------------------------------------------------------------------
 Estructura de parámetros para cada hilo
------------------------------------------------------------------------------*/
struct parametros{
	int nH;     /* Número total de hilos */
	int idH;    /* Identificador del hilo */
	int N;      /* Tamaño de la matriz NxN */
};

/*------------------------------------------------------------------------------
 Función: mxmPosixFxC
 Descripción:
    Función ejecutada por cada hilo. Cada hilo calcula un bloque de filas
    de la matriz resultado C, realizando la multiplicación clásica de
    matrices A x B.

 Parámetros:
    variables -> puntero a estructura parametros con:
                 idH : identificador del hilo
                 nH  : número total de hilos
                 N   : dimensión de la matriz

 Retorna:
    void*
------------------------------------------------------------------------------*/
void *mxmPosixFxC(void *variables){
	struct parametros *data = (struct parametros *)variables;
	
	/* Obtención de datos enviados al hilo */
	int idH		= data->idH;
	int nH		= data->nH;
	int D		= data->N;

	/* Cálculo del rango de filas asignadas al hilo */
	int filaI	= (D/nH)*idH;
	int filaF	= (D/nH)*(idH+1);

    /* Recorre las filas asignadas */
    for (int i = filaI; i < filaF; i++){

        /* Recorre columnas de la matriz resultado */
        for (int j = 0; j < D; j++){

			/* Variables auxiliares */
			double *pA, *pB, Suma = 0.0;

			/* Apunta al inicio de la fila i de A */
			pA = matrixA+i*D; 

			/* Apunta a la columna j de B */
			pB = matrixB+j;

            /* Producto punto entre fila de A y columna de B */
            for (int k = 0; k < D; k++, pA++, pB+=D){
				Suma += *pA * *pB;
			}

			/* Guarda resultado en C(i,j) */
			matrixC[i*D+j] = Suma;
		}
	}

	/* Sección crítica protegida con mutex */
	pthread_mutex_lock (&MM_mutex);
	pthread_mutex_unlock (&MM_mutex);

	/* Finaliza el hilo */
	pthread_exit(NULL);
}

/*------------------------------------------------------------------------------
 Función principal
 Descripción:
    Recibe parámetros desde línea de comandos:
        argv[1] -> tamaño de la matriz
        argv[2] -> número de hilos

    Inicializa matrices, crea hilos, espera su finalización y muestra
    resultados.
------------------------------------------------------------------------------*/
int main(int argc, char *argv[]){

	/* Validación de argumentos */
	if (argc < 3){
		printf("Ingreso de argumentos \n $./ejecutable tamMatriz numHilos\n");
		exit(0);	
	}

    /* Lectura de argumentos */
    int N		= (int) atoi(argv[1]); 
    int num_Th 	= (int) atoi(argv[2]); 

    /* Arreglo de hilos */
    pthread_t p[num_Th];

    /* Atributos de creación de hilos */
    pthread_attr_t atrMM;

	/* Reserva dinámica de memoria para matrices */
	matrixA  = (double *)calloc(N*N, sizeof(double));
	matrixB  = (double *)calloc(N*N, sizeof(double));
	matrixC  = (double *)calloc(N*N, sizeof(double));

	/* Inicialización de matrices A y B */
	iniMatrix(matrixA, matrixB, N);

	/* Impresión de matrices de entrada */
	impMatrix(matrixA, N);
	impMatrix(matrixB, N);

	/* Inicio medición de tiempo */
	InicioMuestra();

	/* Inicialización del mutex */
	pthread_mutex_init(&MM_mutex, NULL);

	/* Inicialización de atributos */
	pthread_attr_init(&atrMM);

	/* Hilos en modo joinable */
	pthread_attr_setdetachstate(&atrMM, PTHREAD_CREATE_JOINABLE);

    /* Creación de hilos */
    for (int j=0; j<num_Th; j++){

		/* Reserva memoria para parámetros del hilo */
		struct parametros *datos = (struct parametros *) malloc(sizeof(struct parametros)); 

		datos->idH = j;
		datos->nH  = num_Th;
		datos->N   = N;

        /* Lanzamiento del hilo */
        pthread_create(&p[j], &atrMM, mxmPosixFxC, (void *)datos);
	}

    /* Espera a que finalicen todos los hilos */
    for (int j=0; j<num_Th; j++)
        pthread_join(p[j], NULL);

	/* Fin medición de tiempo */
	FinMuestra();
	
	/* Impresión matriz resultado */
	impMatrix(matrixC, N);

	/* Liberación de Memoria */
	free(matrixA);
	free(matrixB);
	free(matrixC);

	/* Destrucción de atributos y mutex */
	pthread_attr_destroy(&atrMM);
	pthread_mutex_destroy(&MM_mutex);

	/* Finaliza proceso principal */
	pthread_exit(NULL);

	return 0;
}