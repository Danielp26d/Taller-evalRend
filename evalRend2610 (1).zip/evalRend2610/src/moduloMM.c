/*#######################################################################################
#* Fecha:
#* Autor: J. Corredor, PhD
#* Programa:
#*      Multiplicación de Matrices algoritmo clásico
#* Versión:
#*      Paralelismo con Hilos Pthreads "Posix" 
######################################################################################*/

#include <stdio.h>      // Entrada/salida (printf)
#include <pthread.h>    // Manejo de hilos POSIX
#include <unistd.h>     // Funciones del sistema
#include <stdlib.h>     // Memoria dinámica y utilidades
#include <time.h>       
#include <sys/time.h>
#include "moduloMM.h"   // Funciones de matrices

// Mutex (no necesario en este caso, pero se declara)
pthread_mutex_t MM_mutex;

// Punteros globales a matrices
double *matrixA, *matrixB, *matrixC;

// Estructura para pasar parámetros a cada hilo
struct parametros{
    int nH;     // Número total de hilos
    int idH;    // ID del hilo
    int N;      // Tamaño de la matriz
};

/**
 * @brief Función que ejecuta cada hilo para multiplicar matrices.
 * 
 * Cada hilo calcula un bloque de filas de la matriz resultado.
 */
void *mxmPosixFxC(void *variables){

    // Casting de los parámetros recibidos
    struct parametros *data = (struct parametros *)variables;
    
    int idH = data->idH;
    int nH  = data->nH;
    int D   = data->N;

    // División de trabajo (corregida para cubrir todas las filas)
    int filasxH = D / nH;
    int filaI   = idH * filasxH;
    int filaF   = (idH == nH - 1) ? D : filaI + filasxH;

    // Multiplicación de matrices
    for (int i = filaI; i < filaF; i++){
        for (int j = 0; j < D; j++){

            double *pA, *pB, suma = 0.0;

            pA = matrixA + i * D; // fila de A
            pB = matrixB + j;     // columna de B

            // Producto punto
            for (int k = 0; k < D; k++, pA++, pB += D){
                suma += (*pA) * (*pB);
            }

            matrixC[i * D + j] = suma;
        }
    }

    // ❌ Mutex eliminado (no necesario porque cada hilo escribe en filas distintas)

    pthread_exit(NULL);
}

/**
 * @brief Función principal
 */
int main(int argc, char *argv[]){

    // Validación de argumentos
    if (argc < 3){
        printf("Uso: ./ejecutable tamMatriz numHilos\n");
        exit(0);
    }

    int N   = atoi(argv[1]); // Tamaño de la matriz
    int nH  = atoi(argv[2]); // Número de hilos

    // Reserva de memoria
    matrixA = (double *) calloc(N*N, sizeof(double));
    matrixB = (double *) calloc(N*N, sizeof(double));
    matrixC = (double *) calloc(N*N, sizeof(double));

    // Inicialización
    iniMatrix(matrixA, matrixB, N);

    // Impresión (opcional)
    if(N < 11){
        impMatrix(matrixA, N);
        impMatrix(matrixB, N);
    }

    // Inicialización de hilos
    pthread_t threads[nH];
    struct parametros datos[nH];

    // Inicio de medición
    InicioMuestra();

    // Creación de hilos
    for(int i = 0; i < nH; i++){
        datos[i].idH = i;
        datos[i].nH  = nH;
        datos[i].N   = N;

        pthread_create(&threads[i], NULL, mxmPosixFxC, (void *)&datos[i]);
    }

    // Espera a que todos los hilos terminen
    for(int i = 0; i < nH; i++){
        pthread_join(threads[i], NULL);
    }

    // Fin de medición
    FinMuestra();

    // Impresión de resultado si es pequeño
    if(N < 11){
        printf("\nMatriz Resultado:\n");
        impMatrix(matrixC, N);
    }

    // Liberación de memoria
    free(matrixA);
    free(matrixB);
    free(matrixC);

    return 0;
}
