/*#######################################################################################
#* Fecha:
#* Autor: J. Corredor, PhD
#* Programa:
#*      Multiplicación de Matrices algoritmo clásico
#* Versión:
#*      Paralelismo con Hilos Pthreads "Posix" 
######################################################################################*/

#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include "moduloMM.h" 

/*------------------------------------------------------------------------------
 Variables globales
------------------------------------------------------------------------------*/

/* Mutex para sincronización entre hilos */
pthread_mutex_t MM_mutex;

/* Punteros globales para matrices:
   A -> matriz original A
   B -> matriz original B
   T -> matriz transpuesta de B
   C -> matriz resultado */
double *matrixA, *matrixB, *matrixT, *matrixC; 

/*------------------------------------------------------------------------------
 Estructura de parámetros enviada a cada hilo
------------------------------------------------------------------------------*/
struct parametros{
        int nH;     /* Número total de hilos */
        int idH;    /* Identificador del hilo */
        int N;      /* Tamaño de la matriz NxN */
};

/*------------------------------------------------------------------------------
 Función: mxmPosixFxT
 Descripción:
    Función ejecutada por cada hilo. Multiplica una porción de filas de la
    matriz A con la matriz transpuesta T (transpuesta de B), almacenando
    el resultado en C.

    El uso de la matriz transpuesta mejora el acceso en memoria al trabajar
    con datos contiguos.

 Parámetros:
    variables -> puntero a estructura parametros

 Retorna:
    void *
------------------------------------------------------------------------------*/
void *mxmPosixFxT(void *variables){

	struct parametros *data = (struct parametros *)variables;

	/* Datos recibidos por el hilo */
	int idH		= data->idH;
	int nH		= data->nH;
	int D		= data->N;

	/* Rango de filas asignadas al hilo */
	int filaI	= (D/nH)*idH;
	int filaF	= (D/nH)*(idH+1);

    /* Recorre filas asignadas */
    for (int i = filaI; i < filaF; i++){

        /* Recorre columnas de la matriz resultado */
        for (int j = 0; j < D; j++){

			double *pA, *pB, Suma = 0.0;

			/* Inicio fila i de A */
			pA = matrixA + i*D; 

			/* Inicio fila j de T (equivale columna j de B) */
			pB = matrixT + j*D;

            /* Producto punto */
            for (int k = 0; k < D; k++, pA++, pB++){
				Suma += *pA * *pB;
			}

			/* Guarda resultado */
			matrixC[i*D+j] = Suma;
		}
	}

	/* Sección crítica protegida con mutex */
	pthread_mutex_lock (&MM_mutex);
	pthread_mutex_unlock (&MM_mutex);

	/* Finaliza hilo */
	pthread_exit(NULL);
}

/*------------------------------------------------------------------------------
 Función principal
 Descripción:
    - Lee argumentos desde línea de comandos
    - Reserva memoria para matrices
    - Inicializa matrices
    - Transpone la matriz B en T
    - Crea hilos para multiplicación paralela
    - Espera finalización de hilos
    - Imprime resultados
------------------------------------------------------------------------------*/
int main(int argc, char *argv[]){

	/* Validación de argumentos */
	if (argc < 3){
		printf("Ingreso de argumentos \n $./ejecutable tamMatriz numHilos\n");
		exit(0);	
	}

    /* Lectura de argumentos */
    int N 		= (int) atoi(argv[1]); 
    int num_Th	= (int) atoi(argv[2]); 

    /* Vector de hilos */
    pthread_t p[num_Th];

    /* Atributos de hilos */
    pthread_attr_t atrMM;

	/* Reserva dinámica de memoria */
	matrixA  = (double *)calloc(N*N, sizeof(double));
	matrixB  = (double *)calloc(N*N, sizeof(double));
	matrixC  = (double *)calloc(N*N, sizeof(double));
	matrixT  = (double *)calloc(N*N, sizeof(double));

	/* Inicialización matrices A y B */
	iniMatrix(matrixA, matrixB, N);

	/* Impresión matrices originales */
	impMatrix(matrixA, N);
	impMatrix(matrixB, N);

	/* Inicio medición tiempo */
	InicioMuestra();

	/* Transpuesta de B almacenada en T */
	matrixTRP(N, matrixB, matrixT);

	/* Inicialización mutex */
	pthread_mutex_init(&MM_mutex, NULL);

	/* Inicialización atributos */
	pthread_attr_init(&atrMM);

	/* Hilos tipo joinable */
	pthread_attr_setdetachstate(&atrMM, PTHREAD_CREATE_JOINABLE);

    /* Creación de hilos */
    for (int j=0; j<num_Th; j++){

		struct parametros *datos = (struct parametros *) malloc(sizeof(struct parametros)); 

		datos->idH = j;
		datos->nH  = num_Th;
		datos->N   = N;

        pthread_create(&p[j], &atrMM, mxmPosixFxT, (void *)datos);
	}

    /* Espera de finalización */
    for (int j=0; j<num_Th; j++)
        pthread_join(p[j], NULL);

	/* Fin medición tiempo */
	FinMuestra();
	
	/* Impresión matriz resultado */
	impMatrix(matrixC, N);

	/* Liberación de memoria */
	free(matrixA);
	free(matrixB);
	free(matrixC);
	free(matrixT);

	/* Destrucción de atributos y mutex */
	pthread_attr_destroy(&atrMM);
	pthread_mutex_destroy(&MM_mutex);

	/* Finaliza programa */
	pthread_exit(NULL);

	return 0;
}